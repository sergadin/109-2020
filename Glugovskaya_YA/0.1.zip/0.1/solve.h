typedef double (*dFUNC)(double x);

double *func(dFUNC funcs, int n, double *x);
