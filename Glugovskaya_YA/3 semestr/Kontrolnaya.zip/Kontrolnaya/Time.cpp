#include <string>
#include "Time.h"
#include <iostream>
#include <stdio.h>


PortrPart::PortrPart (const std::string& NameOfProgr, int SizeOfMasKat){
	int i = 0;
	if (SizeOfMasKat < 0){
		throw Error(-1, std::string("Размер не может быть отрицательным"));
	}
	
//	if (Met_ >= size - 1){
//		throw TimeError(-2, std::string("Значение больше размера массива"));
//	}
	
	//MasofKat_ = new int [SizeOfMasKat];
	//MasofTime_ = new int[size];
	
	MasofOperInKat_ = new int [SizeOfMasKat];
	MasofSumInEvKat_ = new double [SizeOfMasKat];
	
	SizeOfMasKat_ = SizeOfMasKat;
	//size_=size;

	for (i = 0; i < SizeOfMasKat; i++)
		MasofOperInKat_[i] = 0;
		MasofSumInEvKat_[i] = 0;
}

PortrPart::~PortrPart(){
	delete[] MasofSumInEvKat_;
	delete[] MasofOperInKat_;
}

void PortrPart::SpendMoney(int InWhatKat, double HowMuch){
	if (InWhatKat > this -> SizeOfMasKat_){
		printf("Такой категории нет");
		throw (-3, "Такой категории нет");
	}
	MasofOperInKat_[InWhatKat] +=1;
	MasofSumInEvKat_[InWhatKat] +=HowMuch;
	return;
}

void Check(const PortrPart &Par1, const PortrPart &Par2){
	if (Par1.NameOfProgr_ == Par2.NameOfProgr_  && Par1.SizeOfMasKat_ == Par2.SizeOfMasKat_){
		printf("Тут два одинаковых человека\n");
		for (int  i = 0; i < Par1.SizeOfMasKat_; i++){
			Par1.MasofOperInKat_[i] += Par2.MasofOperInKat_[i];
			Par1.MasofSumInEvKat_[i] += Par2.MasofSumInEvKat_[i];
		}
		Par2.~PortrPart();
	}
}
/*
void Time::GetMessage(const Time & Getter){
	
	if (Getter.size_ != size_){
		throw TimeError (-3, std::string("Размеры не соответствуют"));
		return;
	}
	
	if (Met_ == Getter.Met_){
		for (int i = 0; i<size_; i++){
			if (MasofTime_[i] != Getter.MasofTime_[i]){
				throw TimeError(-4, std::string("Нельзя получить сообщение"));
			}
		}
		return;
	}
	
	
	for(int i = 0; i < size_; i ++){
		if(i != Met_){
			if(Getter.MasofTime_[i] > MasofTime_[i]){
				MasofTime_[i] = Getter.MasofTime_[i];		
			}	
		}
		else
		{
			MasofTime_[i] += 1;
		}
	}
	std::cout << "Получение сообщения" << this <<std::endl;
}*/

/*bool operator <= (const Time& Sender, const Time& Getter){
	if(&Sender == &Getter){
         return true;
    }
	
	if(Sender.size_ != Getter.size_){
		throw TimeError(-5, std::string("Разные размеры получателя и отправителя"));
		return false;
	}
	
	for(int i = 0; i < Sender.size_; i ++){
		if(Sender.MasofTime_[i] > Getter.MasofTime_[i]){
			return false;
		}
	}
	return true;
}*/
	
operator == (const PortrPart &Par1, const PortrPart &Par2){
	int Sum1 = 0, Sum2 = 0; 
	if (Par1.SizeOfMasKat_ != Par2.SizeOfMasKat_){
		throw Error (-2, std::string("Не тех сравниваете"));
	}

	for (int i=0; i < Par1.SizeOfMasKat_; i++){
		Sum1 += Par1.MasofSumInEvKat_[i];
		Sum2 += Par2.MasofSumInEvKat_[i];
	}
	if (Sum1 < Sum2){
		return -1;
	}
	
	if (Sum1 == Sum2){
		return 0;
	}
	
	if (Sum1 > Sum2){
		return 1;
	}
}
	
std::ostream & operator<<(std::ostream &os, const PortrPart &Par)
{
	os << "Количество категорий " << Par.SizeOfMasKat_ << "  Количество операций в каждой категории и количество денег \n";
	for(int i = 0; i < Par.SizeOfMasKat_; i ++)
	{
		os << Par.MasofOperInKat_[i] << "  " << Par.MasofSumInEvKat_[i]  << "\n";
	}
	return os;

}
	
/*Time& Time::operator=(const Time & Sender){
        if(this == &Sender){
            return *this;
        }
        delete[] MasofTime_;
        MasofTime_ = new int[Sender.size_];
		size_ = Sender.size_;
        Met_ = Sender.Met_;
        for(int i = 0; i < size_; i++)
	{
                MasofTime_[i] = Sender.MasofTime_[i];
	}
        return *this;
}

std::ostream & operator<<(std::ostream &os, const Time&q)
{
	os << "Количество процессов " << q.size_ << "  Количество событий: " << q.Met_;
	for(int i = 0; i < q.size_; i ++)
	{
		os << "\t" << q.MasofTime_[i] << "\n";
	}
	return os;

}*/