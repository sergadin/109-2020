#include <iostream>
#include "Time.h"

using namespace std;

int main(){
	
	PortrPart Par0(std::string("Банк"), 2);
	
//	Time Proc0(3,0);
	
	try
	{
		PortrPart Par1(std::string("Банк"), 4);
		Par1.SpendMoney(2, 30);
		Par1.SpendMoney(2, 50.5);
		Check(Par0, Par1);
		//Par1.SpendMoney(7, 50.5);
		/*Time Proc2(3, 2);
		Time Proc3(5, 2);
		Time Proc4(3, 2);
		Proc0.InEvent();
		Proc1.InEvent();
		Proc0.GetMessage(Proc1);
		*/

  		std::cout<< Par1 << endl;
  		return 0;
	}
	catch (Error &err){
		std::cout << "EXC  "<< err.get_reason() << std::endl;
	}
	std::cout << Par0 << endl;
    return 0;
}